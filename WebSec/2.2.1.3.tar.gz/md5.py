import re
import random
import string
import hashlib

while True:
	random_int = random.choice(list(range(5, 31)))
	random_str = ''.join(random.choice(string.ascii_letters + string.digits) for i in range(random_int))
	result = hashlib.md5(random_str.encode('utf-8'))
	regex_for_indicator = re.search(b".*?'(or|Or|OR|oR)'[1-9]+?.*", result.digest())
	if regex_for_indicator:
		print(random_str)
		break